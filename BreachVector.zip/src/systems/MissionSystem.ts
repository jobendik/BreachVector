import { missionText } from '../data/missionText';
import { GameEvents, eventBus } from '../game/events';
import type { LevelData, MissionObjective } from '../game/types';

export class MissionSystem {
  private readonly terminalFlags = new Map<string, boolean>();
  captainKilled = false;

  constructor(private readonly level: LevelData) {
    for (const id of level.requiredTerminalIds) {
      this.terminalFlags.set(id, false);
    }
    this.emit();
  }

  terminalHacked(id: string): void {
    if (!this.terminalFlags.has(id) || this.terminalFlags.get(id)) {
      return;
    }
    this.terminalFlags.set(id, true);
    eventBus.emit(GameEvents.TacticalLog, { message: missionText.terminalComplete(id) });
    if (this.terminalsComplete() && !this.level.requiresCaptainKill) {
      eventBus.emit(GameEvents.TacticalLog, { message: missionText.extractionReady });
    }
    this.emit();
  }

  commandTargetKilled(): void {
    if (this.captainKilled) {
      return;
    }
    this.captainKilled = true;
    eventBus.emit(GameEvents.TacticalLog, { message: missionText.captainDown });
    if (this.canExtract()) {
      eventBus.emit(GameEvents.TacticalLog, { message: missionText.extractionReady });
    }
    this.emit();
  }

  terminalsComplete(): boolean {
    return [...this.terminalFlags.values()].every(Boolean);
  }

  canExtract(): boolean {
    return this.terminalsComplete() && (!this.level.requiresCaptainKill || this.captainKilled);
  }

  objectives(): MissionObjective[] {
    const terminalObjectives = [...this.terminalFlags.entries()].map(([id, completed]) => ({
      id: `terminal-${id}`,
      label: `Hack terminal ${id.toUpperCase()}`,
      completed,
      emphasis: completed ? ('success' as const) : ('normal' as const)
    }));

    const captainObjective: MissionObjective = {
      id: 'captain',
      label: 'Neutralize command unit',
      completed: !this.level.requiresCaptainKill || this.captainKilled,
      emphasis: this.captainKilled ? 'success' : 'critical'
    };

    const extractObjective: MissionObjective = {
      id: 'extract',
      label: 'Reach extraction zone',
      completed: false,
      emphasis: this.canExtract() ? 'warning' : 'normal'
    };

    return [...terminalObjectives, captainObjective, extractObjective];
  }

  emit(): void {
    eventBus.emit(GameEvents.MissionUpdated, this.objectives());
  }
}
