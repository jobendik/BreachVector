import Phaser from 'phaser';
import type { Door } from '../entities/Door';
import type { Enemy } from '../entities/Enemy';
import type { Pickup } from '../entities/Pickup';
import type { Player } from '../entities/Player';
import type { Projectile } from '../entities/Projectile';
import type { Prop } from '../entities/Prop';
import type { CombatSystem } from './CombatSystem';

type ArcadeObject =
  | Phaser.Types.Physics.Arcade.GameObjectWithBody
  | Phaser.Physics.Arcade.Body
  | Phaser.Physics.Arcade.StaticBody
  | Phaser.Tilemaps.Tile;

interface CollisionWorld {
  scene: Phaser.Scene;
  player: Player;
  walls: Phaser.Physics.Arcade.StaticGroup;
  doors: Phaser.Physics.Arcade.Group;
  enemies: Phaser.Physics.Arcade.Group;
  propsGroup: Phaser.Physics.Arcade.Group;
  projectiles: Phaser.Physics.Arcade.Group;
  grenades: Phaser.Physics.Arcade.Group;
  pickups: Phaser.Physics.Arcade.Group;
  combat: CombatSystem;
  log(message: string): void;
  effects: {
    hit(x: number, y: number, color?: number): void;
  };
  audio: {
    play(id: 'pickup'): void;
  };
}

export class CollisionSystem {
  constructor(private readonly world: CollisionWorld) {}

  setup(): void {
    const physics = this.world.scene.physics;
    physics.add.collider(this.world.player, this.world.walls);
    physics.add.collider(this.world.player, this.world.doors, undefined, this.closedDoorProcess, this);
    physics.add.collider(this.world.player, this.world.propsGroup);
    physics.add.collider(this.world.enemies, this.world.walls);
    physics.add.collider(this.world.enemies, this.world.doors, undefined, this.closedDoorProcess, this);
    physics.add.collider(this.world.enemies, this.world.propsGroup);
    physics.add.collider(this.world.enemies, this.world.enemies);

    physics.add.collider(this.world.grenades, this.world.walls);
    physics.add.collider(this.world.grenades, this.world.doors, undefined, this.closedDoorProcess, this);
    physics.add.collider(this.world.grenades, this.world.propsGroup);

    physics.add.collider(this.world.projectiles, this.world.walls, this.projectileWallHit, undefined, this);
    physics.add.collider(this.world.projectiles, this.world.doors, this.projectileDoorHit, this.closedDoorProcess, this);
    physics.add.collider(this.world.projectiles, this.world.propsGroup, this.projectilePropHit, undefined, this);
    physics.add.overlap(this.world.projectiles, this.world.enemies, this.projectileEnemyHit, undefined, this);
    physics.add.overlap(this.world.projectiles, this.world.player, this.projectilePlayerHit, undefined, this);
    physics.add.overlap(this.world.player, this.world.pickups, this.pickupHit, undefined, this);
  }

  private closedDoorProcess(_a: ArcadeObject, b: ArcadeObject): boolean {
    const door = b as unknown as Door;
    return !door.open;
  }

  private projectileWallHit(projectileObject: ArcadeObject): void {
    const projectile = projectileObject as unknown as Projectile;
    if (!projectile.active) {
      return;
    }
    this.world.effects.hit(projectile.x, projectile.y, projectile.color);
    projectile.destroy();
  }

  private projectileDoorHit(projectileObject: ArcadeObject, doorObject: ArcadeObject): void {
    const projectile = projectileObject as unknown as Projectile;
    const door = doorObject as unknown as Door;
    if (!projectile.active || door.open) {
      return;
    }
    this.world.effects.hit(projectile.x, projectile.y, projectile.color);
    projectile.destroy();
  }

  private projectilePropHit(projectileObject: ArcadeObject, propObject: ArcadeObject): void {
    const projectile = projectileObject as unknown as Projectile;
    const prop = propObject as unknown as Prop;
    if (!projectile.active || prop.dead) {
      return;
    }
    this.world.combat.damageProp(prop, projectile.damage, projectile.damageSource);
    projectile.consumePierce();
  }

  private projectileEnemyHit(projectileObject: ArcadeObject, enemyObject: ArcadeObject): void {
    const projectile = projectileObject as unknown as Projectile;
    const enemy = enemyObject as unknown as Enemy;
    if (!projectile.active || enemy.dead || projectile.ownerTeam !== 'player' || projectile.hitActors.has(enemy.actorId)) {
      return;
    }
    projectile.hitActors.add(enemy.actorId);
    this.world.combat.damageActor(enemy, projectile.damage, projectile.damageSource);
    projectile.consumePierce();
  }

  private projectilePlayerHit(projectileObject: ArcadeObject, playerObject: ArcadeObject): void {
    const projectile = projectileObject as unknown as Projectile;
    const player = playerObject as unknown as Player;
    if (!projectile.active || player.dead || projectile.ownerTeam !== 'enemy') {
      return;
    }
    this.world.combat.damageActor(player, projectile.damage, projectile.damageSource);
    projectile.destroy();
  }

  private pickupHit(playerObject: ArcadeObject, pickupObject: ArcadeObject): void {
    const player = playerObject as unknown as Player;
    const pickup = pickupObject as unknown as Pickup;
    if (!pickup.active) {
      return;
    }
    const message = pickup.apply(player);
    this.world.audio.play('pickup');
    this.world.log(message);
  }
}
