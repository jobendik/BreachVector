import Phaser from 'phaser';
import { levels, getLevel } from '../data/levels';
import { missionText } from '../data/missionText';
import { DEPTHS, PLAYER_BALANCE } from '../game/constants';
import { GameEvents, eventBus } from '../game/events';
import type { HudState, LevelData, PickupType, RectData } from '../game/types';
import { Door } from '../entities/Door';
import { Enemy } from '../entities/Enemy';
import { ExtractionZone } from '../entities/ExtractionZone';
import { Grenade } from '../entities/Grenade';
import { Pickup } from '../entities/Pickup';
import { Player } from '../entities/Player';
import { Projectile } from '../entities/Projectile';
import { Prop } from '../entities/Prop';
import { Terminal } from '../entities/Terminal';
import { AlertSystem } from '../systems/AlertSystem';
import { AudioSystem } from '../systems/AudioSystem';
import { CollisionSystem } from '../systems/CollisionSystem';
import { CombatSystem } from '../systems/CombatSystem';
import { EffectsSystem } from '../systems/EffectsSystem';
import { EnemyAISystem } from '../systems/EnemyAISystem';
import { InputSystem } from '../systems/InputSystem';
import { MinimapSystem } from '../systems/MinimapSystem';
import { MissionSystem } from '../systems/MissionSystem';
import { VisionSystem } from '../systems/VisionSystem';
import { WeaponSystem } from '../systems/WeaponSystem';
import { pointInRect, rectCenter } from '../utils/geometry';

export class GameScene extends Phaser.Scene {
  level!: LevelData;
  levelIndex = 0;
  player!: Player;

  wallGroup!: Phaser.Physics.Arcade.StaticGroup;
  doorGroup!: Phaser.Physics.Arcade.Group;
  enemyGroup!: Phaser.Physics.Arcade.Group;
  propsGroup!: Phaser.Physics.Arcade.Group;
  projectileGroup!: Phaser.Physics.Arcade.Group;
  grenadeGroup!: Phaser.Physics.Arcade.Group;
  pickupGroup!: Phaser.Physics.Arcade.Group;

  doorEntities: Door[] = [];
  terminalEntities: Terminal[] = [];
  propEntities: Prop[] = [];
  enemyEntities: Enemy[] = [];
  projectileEntities: Projectile[] = [];
  grenadeEntities: Grenade[] = [];
  coverPoints: Phaser.Math.Vector2[] = [];

  effects!: EffectsSystem;
  audio!: AudioSystem;
  inputSystem!: InputSystem;
  weapons!: WeaponSystem;
  combat!: CombatSystem;
  collisions!: CollisionSystem;
  vision!: VisionSystem;
  mission!: MissionSystem;
  alert!: AlertSystem;
  enemyAI!: EnemyAISystem;
  minimap!: MinimapSystem;

  debugGraphics!: Phaser.GameObjects.Graphics;
  private floorGraphics!: Phaser.GameObjects.Graphics;
  private visibilityGraphics!: Phaser.GameObjects.Graphics;
  private extractionZone!: ExtractionZone;
  private debugEnabled = false;
  private interactionPrompt = '';
  private tacticalLog: string[] = [];
  private minimapTimer = 0;
  private sectorEnding = false;

  constructor() {
    super('GameScene');
  }

  create(data: { levelIndex?: number }): void {
    this.scene.stop('UIScene');
    this.levelIndex = Phaser.Math.Clamp(data.levelIndex ?? 0, 0, levels.length - 1);
    this.level = getLevel(this.levelIndex);
    this.sectorEnding = false;
    this.tacticalLog = [];
    this.interactionPrompt = '';
    this.debugEnabled = false;

    this.physics.world.setBounds(0, 0, this.level.width, this.level.height);
    this.cameras.main.setBounds(0, 0, this.level.width, this.level.height);
    this.cameras.main.setBackgroundColor(0x020617);

    this.createGroups();
    this.drawEnvironment();
    this.createLevelEntities();
    this.createSystems();
    this.collisions.setup();

    this.cameras.main.startFollow(this.player, true, 0.12, 0.12);
    this.cameras.main.setZoom(1);

    this.scene.launch('UIScene');
    this.events.once(Phaser.Scenes.Events.SHUTDOWN, () => this.scene.stop('UIScene'));
    this.log(`Sector: ${this.level.name}`);
    this.log(this.level.briefing);
    this.mission.emit();
  }

  update(time: number, deltaMs: number): void {
    if (!this.player || this.player.dead || this.sectorEnding) {
      return;
    }
    const deltaSeconds = Math.min(deltaMs / 1000, 0.05);
    this.inputSystem.update();
    this.audio.resume();

    if (this.inputSystem.pausePressed()) {
      this.scene.launch('PauseScene', { levelIndex: this.levelIndex });
      this.scene.pause();
      return;
    }

    if (this.inputSystem.debugPressed()) {
      this.debugEnabled = !this.debugEnabled;
      eventBus.emit(GameEvents.DebugChanged, { enabled: this.debugEnabled });
      this.log(this.debugEnabled ? 'Debug overlay enabled' : 'Debug overlay disabled');
    }

    const pointerWorld = this.inputSystem.pointerWorld(this.cameras.main);
    const movement = this.inputSystem.movementVector();

    this.player.updateTimers(deltaSeconds);
    this.player.aimAt(pointerWorld);
    this.player.applyMovement(movement, this.inputSystem.slowWalkHeld(), deltaSeconds);

    const weaponIndex = this.inputSystem.weaponPressed();
    if (weaponIndex !== null && this.player.switchWeapon(weaponIndex)) {
      this.log(`Weapon: ${this.player.selectedWeapon.definition.displayName}`);
    }

    if (this.inputSystem.dashPressed() && this.player.tryDash(movement)) {
      this.audio.play('dash');
      this.effects.shake(2.4);
      this.emitNoise(this.player.positionVector, 260, true);
    }

    if (this.inputSystem.reloadPressed()) {
      this.weapons.startReload(this.player);
    }

    this.weapons.tryFirePlayer(
      this.player,
      pointerWorld,
      this.inputSystem.primaryHeld(),
      this.inputSystem.consumePrimaryPressed()
    );

    if (this.inputSystem.consumeSecondaryPressed()) {
      this.weapons.throwGrenade(this.player, pointerWorld);
    }

    if (this.inputSystem.meleePressed()) {
      this.handleMelee();
    }

    this.handleInteractions(deltaSeconds);
    this.enemyAI.update(deltaSeconds, this.debugEnabled);
    this.updateProjectiles(deltaSeconds);
    this.updateGrenades(deltaSeconds);
    this.alert.update(deltaSeconds);
    this.updateVisibility(time / 1000);
    this.updateCameraAim(pointerWorld);
    this.updateExtraction(time / 1000);
    this.cleanupInactiveEntities();
    this.emitHudState();
    this.emitMinimap(deltaSeconds);
  }

  spawnProjectile(projectile: Projectile): void {
    this.projectileGroup.add(projectile);
    this.projectileEntities.push(projectile);
  }

  spawnGrenade(grenade: Grenade): void {
    this.grenadeGroup.add(grenade);
    this.grenadeEntities.push(grenade);
  }

  emitNoise(point: Phaser.Math.Vector2, radius: number, important = false): void {
    const ring = this.add.circle(point.x, point.y, 8).setDepth(DEPTHS.effects);
    ring.setStrokeStyle(2, important ? 0xef4444 : 0x94a3b8, important ? 0.5 : 0.28);
    ring.setFillStyle(0x000000, 0);
    this.tweens.add({
      targets: ring,
      radius,
      alpha: 0,
      duration: important ? 620 : 460,
      ease: 'Cubic.easeOut',
      onComplete: () => ring.destroy()
    });

    for (const enemy of this.enemyEntities) {
      if (enemy.dead) {
        continue;
      }
      if (Phaser.Math.Distance.Between(point.x, point.y, enemy.x, enemy.y) <= radius) {
        enemy.hearNoise(point, important);
      }
    }
    if (important) {
      this.alert.raiseSearch(3.2);
    }
  }

  getClosedDoorRects(): RectData[] {
    return this.doorEntities.filter((door) => !door.open).map((door) => door.rect);
  }

  getSolidPropRects(blockLosOnly = false): RectData[] {
    return this.propEntities
      .filter((prop) => !prop.dead && (!blockLosOnly || prop.blocksLineOfSight))
      .map((prop) => prop.rect);
  }

  hasLineOfSight(a: Phaser.Math.Vector2, b: Phaser.Math.Vector2): boolean {
    return this.vision.hasLineOfSight(a, b);
  }

  onEnemyKilled(enemy: Enemy): void {
    this.log(`${enemy.config.displayName} neutralized`);
    if (enemy.role === 'captain') {
      this.mission.commandTargetKilled();
    }
    if (Math.random() < 0.28) {
      this.dropSupply(enemy.x, enemy.y);
    }
  }

  onPlayerKilled(): void {
    if (this.sectorEnding) {
      return;
    }
    this.sectorEnding = true;
    this.log(missionText.gameOver);
    this.time.delayedCall(650, () => {
      this.scene.stop('UIScene');
      this.scene.start('GameOverScene', { levelIndex: this.levelIndex });
    });
  }

  log(message: string): void {
    this.tacticalLog.push(message);
    this.tacticalLog = this.tacticalLog.slice(-8);
    eventBus.emit(GameEvents.TacticalLog, { message });
  }

  private createGroups(): void {
    this.wallGroup = this.physics.add.staticGroup();
    this.doorGroup = this.physics.add.group();
    this.enemyGroup = this.physics.add.group();
    this.propsGroup = this.physics.add.group();
    this.projectileGroup = this.physics.add.group();
    this.grenadeGroup = this.physics.add.group();
    this.pickupGroup = this.physics.add.group();

    this.doorEntities = [];
    this.terminalEntities = [];
    this.propEntities = [];
    this.enemyEntities = [];
    this.projectileEntities = [];
    this.grenadeEntities = [];
    this.coverPoints = [];
  }

  private drawEnvironment(): void {
    this.floorGraphics = this.add.graphics().setDepth(DEPTHS.floor);
    this.floorGraphics.fillStyle(0x06111f, 1);
    this.floorGraphics.fillRect(0, 0, this.level.width, this.level.height);
    this.floorGraphics.lineStyle(1, 0x38bdf8, 0.08);
    for (let x = 0; x <= this.level.width; x += 100) {
      this.floorGraphics.lineBetween(x, 0, x, this.level.height);
    }
    for (let y = 0; y <= this.level.height; y += 100) {
      this.floorGraphics.lineBetween(0, y, this.level.width, y);
    }
    this.floorGraphics.lineStyle(1, 0x10b981, 0.08);
    for (let x = 50; x <= this.level.width; x += 200) {
      this.floorGraphics.lineBetween(x, 0, x, this.level.height);
    }

    for (const wall of this.level.walls) {
      const rectangle = this.add
        .rectangle(wall.x + wall.w / 2, wall.y + wall.h / 2, wall.w, wall.h, 0x162033, 1)
        .setStrokeStyle(2, 0x38bdf8, 0.26)
        .setDepth(DEPTHS.props);
      this.physics.add.existing(rectangle, true);
      const body = rectangle.body as Phaser.Physics.Arcade.StaticBody;
      body.setSize(wall.w, wall.h);
      body.updateFromGameObject();
      this.wallGroup.add(rectangle);
    }

    this.visibilityGraphics = this.add.graphics().setDepth(DEPTHS.actors - 2);
    this.debugGraphics = this.add.graphics().setDepth(DEPTHS.debug);
  }

  private createLevelEntities(): void {
    this.extractionZone = new ExtractionZone(this, this.level.extraction);

    for (const doorData of this.level.doors) {
      const door = new Door(this, doorData);
      this.doorEntities.push(door);
      this.doorGroup.add(door);
    }

    for (const terminalData of this.level.terminals) {
      const terminal = new Terminal(this, terminalData);
      this.terminalEntities.push(terminal);
    }

    for (const propData of this.level.props) {
      const prop = new Prop(this, propData);
      this.propEntities.push(prop);
      this.propsGroup.add(prop);
    }

    for (const pickupData of this.level.pickups) {
      const pickup = new Pickup(this, pickupData);
      this.pickupGroup.add(pickup);
    }

    this.player = new Player(this, this.level.spawn.x, this.level.spawn.y);

    for (const enemyData of this.level.enemies) {
      const enemy = new Enemy(this, enemyData);
      this.enemyEntities.push(enemy);
      this.enemyGroup.add(enemy);
    }

    this.buildCoverPoints();
  }

  private createSystems(): void {
    this.effects = new EffectsSystem(this);
    this.audio = new AudioSystem();
    this.inputSystem = new InputSystem(this);
    this.alert = new AlertSystem();
    this.mission = new MissionSystem(this.level);
    this.vision = new VisionSystem(this);
    this.minimap = new MinimapSystem(this.level);

    this.weapons = new WeaponSystem({
      scene: this,
      effects: this.effects,
      audio: this.audio,
      spawnProjectile: (projectile) => this.spawnProjectile(projectile),
      spawnGrenade: (grenade) => this.spawnGrenade(grenade),
      emitNoise: (point, radius, important) => this.emitNoise(point, radius, important)
    });

    this.combat = new CombatSystem({
      scene: this,
      player: this.player,
      enemies: this.enemyEntities,
      props: this.propEntities,
      effects: this.effects,
      audio: this.audio,
      hasLineOfSight: (a, b) => this.hasLineOfSight(a, b),
      onEnemyKilled: (enemy) => this.onEnemyKilled(enemy),
      onPlayerKilled: () => this.onPlayerKilled(),
      emitNoise: (point, radius, important) => this.emitNoise(point, radius, important)
    });

    this.enemyAI = new EnemyAISystem({
      player: this.player,
      enemiesList: this.enemyEntities,
      coverPoints: this.coverPoints,
      vision: this.vision,
      alert: this.alert,
      weapons: this.weapons,
      debugGraphics: this.debugGraphics
    });

    this.collisions = new CollisionSystem({
      scene: this,
      player: this.player,
      walls: this.wallGroup,
      doors: this.doorGroup,
      enemies: this.enemyGroup,
      propsGroup: this.propsGroup,
      projectiles: this.projectileGroup,
      grenades: this.grenadeGroup,
      pickups: this.pickupGroup,
      combat: this.combat,
      log: (message) => this.log(message),
      effects: this.effects,
      audio: this.audio
    });
  }

  private buildCoverPoints(): void {
    const rects = [...this.level.walls, ...this.propEntities.map((prop) => prop.rect)];
    for (const rect of rects) {
      const pad = 46;
      const points = [
        new Phaser.Math.Vector2(rect.x - pad, rect.y - pad),
        new Phaser.Math.Vector2(rect.x + rect.w + pad, rect.y - pad),
        new Phaser.Math.Vector2(rect.x - pad, rect.y + rect.h + pad),
        new Phaser.Math.Vector2(rect.x + rect.w + pad, rect.y + rect.h + pad)
      ];
      for (const point of points) {
        if (point.x > 40 && point.y > 40 && point.x < this.level.width - 40 && point.y < this.level.height - 40) {
          this.coverPoints.push(point);
        }
      }
    }
  }

  private handleMelee(): void {
    if (this.player.meleeCooldown > 0) {
      return;
    }
    const target = this.enemyEntities
      .filter((enemy) => !enemy.dead)
      .sort(
        (a, b) =>
          Phaser.Math.Distance.Between(this.player.x, this.player.y, a.x, a.y) -
          Phaser.Math.Distance.Between(this.player.x, this.player.y, b.x, b.y)
      )[0];
    if (!target || Phaser.Math.Distance.Between(this.player.x, this.player.y, target.x, target.y) > PLAYER_BALANCE.meleeRange) {
      return;
    }
    this.player.meleeCooldown = 0.65;
    this.combat.damageActor(target, PLAYER_BALANCE.meleeDamage, {
      team: 'player',
      label: 'Takedown',
      position: { x: this.player.x, y: this.player.y }
    });
    this.effects.shake(2.5);
    this.emitNoise(this.player.positionVector, this.inputSystem.slowWalkHeld() ? 120 : 260, false);
  }

  private handleInteractions(deltaSeconds: number): void {
    this.interactionPrompt = '';
    const terminal = this.nearestTerminal();
    const door = this.nearestDoor();

    for (const candidate of this.terminalEntities) {
      if (candidate !== terminal) {
        candidate.relax(deltaSeconds);
      }
    }

    if (terminal && !terminal.hacked) {
      const progress = Math.round((terminal.progress / terminal.hackTime) * 100);
      this.interactionPrompt = `[E] ${terminal.prompt.toUpperCase()} ${progress}%`;
      if (this.inputSystem.interactHeld()) {
        const wasHacked = terminal.hacked;
        const done = terminal.advance(deltaSeconds);
        terminal.setScale(1 + terminal.progress / terminal.hackTime * 0.08);
        if (done && !wasHacked) {
          this.audio.play('interact');
          this.effects.explosion(terminal.x, terminal.y, 0x38bdf8, 0.45);
          this.mission.terminalHacked(terminal.terminalId);
          for (const matchingDoor of this.doorEntities.filter((doorEntity) => doorEntity.doorId === terminal.terminalId)) {
            matchingDoor.unlock();
            matchingDoor.openDoor();
          }
          this.emitNoise(new Phaser.Math.Vector2(terminal.x, terminal.y), 260, true);
        }
      }
      return;
    }

    if (door && !door.open) {
      this.interactionPrompt = door.locked ? `LOCKED: TERMINAL ${door.doorId.toUpperCase()} REQUIRED` : `[E] OPEN SECURITY DOOR`;
      if (!door.locked && this.inputSystem.interactHeld()) {
        door.openDoor();
        this.audio.play('interact');
        this.log(`Door ${door.doorId.toUpperCase()} opened`);
      }
      return;
    }

    if (this.mission.canExtract() && pointInRect(this.player, this.level.extraction)) {
      this.interactionPrompt = 'EXTRACTION READY';
    }
  }

  private nearestTerminal(): Terminal | undefined {
    return this.terminalEntities
      .filter((terminal) => !terminal.hacked)
      .find((terminal) => Phaser.Math.Distance.Between(this.player.x, this.player.y, terminal.x, terminal.y) <= PLAYER_BALANCE.interactRange);
  }

  private nearestDoor(): Door | undefined {
    return this.doorEntities.find((door) => {
      if (door.open) {
        return false;
      }
      const center = rectCenter(door.rect);
      return Phaser.Math.Distance.Between(this.player.x, this.player.y, center.x, center.y) <= PLAYER_BALANCE.interactRange + 20;
    });
  }

  private updateProjectiles(deltaSeconds: number): void {
    for (const projectile of this.projectileEntities) {
      if (projectile.active) {
        projectile.update(deltaSeconds);
      }
    }
  }

  private updateGrenades(deltaSeconds: number): void {
    for (const grenade of this.grenadeEntities) {
      if (!grenade.active) {
        continue;
      }
      if (grenade.update(deltaSeconds)) {
        const point = new Phaser.Math.Vector2(grenade.x, grenade.y);
        grenade.destroy();
        this.combat.explosion(point, grenade.radius, grenade.damage, grenade.ownerTeam);
      }
    }
  }

  private updateVisibility(timeSeconds: number): void {
    this.visibilityGraphics.clear();
    const detected = this.alert.state === 'detected';
    if (detected) {
      this.visibilityGraphics.fillStyle(0xef4444, 0.1);
      this.visibilityGraphics.fillRect(0, 0, this.level.width, this.level.height);
      for (const enemy of this.enemyEntities) {
        enemy.setAlpha(enemy.dead ? 0 : 1);
      }
      return;
    }

    this.visibilityGraphics.fillStyle(0x020617, this.alert.state === 'searching' ? 0.22 : 0.32);
    this.visibilityGraphics.fillRect(0, 0, this.level.width, this.level.height);
    const polygon = this.vision.visibilityPolygon(this.player.positionVector, 780);
    if (polygon.length > 2) {
      this.visibilityGraphics.fillStyle(0x10b981, 0.035);
      this.visibilityGraphics.beginPath();
      this.visibilityGraphics.moveTo(polygon[0].x, polygon[0].y);
      for (const point of polygon.slice(1)) {
        this.visibilityGraphics.lineTo(point.x, point.y);
      }
      this.visibilityGraphics.closePath();
      this.visibilityGraphics.fillPath();
      this.visibilityGraphics.lineStyle(2, this.alert.state === 'searching' ? 0xf59e0b : 0x10b981, 0.25);
      this.visibilityGraphics.strokePath();
    }
    this.visibilityGraphics.lineStyle(1, 0x38bdf8, 0.24 + Math.sin(timeSeconds * 4) * 0.06);
    this.visibilityGraphics.strokeCircle(this.player.x, this.player.y, 180);

    for (const enemy of this.enemyEntities) {
      if (enemy.dead) {
        enemy.setAlpha(0);
      } else {
        const visible = this.debugEnabled || this.vision.isVisibleFromPlayer(enemy.positionVector) || enemy.recentlyVisible;
        enemy.setAlpha(visible ? 1 : 0.18);
      }
    }
  }

  private updateCameraAim(pointerWorld: Phaser.Math.Vector2): void {
    const offset = pointerWorld.subtract(this.player.positionVector).scale(0.16);
    this.cameras.main.setFollowOffset(-offset.x, -offset.y);
  }

  private updateExtraction(timeSeconds: number): void {
    const canExtract = this.mission.canExtract();
    this.extractionZone.setExtractionReady(canExtract);
    this.extractionZone.pulse(timeSeconds);
    if (canExtract && pointInRect(this.player, this.level.extraction) && !this.sectorEnding) {
      this.sectorEnding = true;
      this.audio.play('complete');
      this.log(missionText.sectorClear);
      this.time.delayedCall(650, () => {
        this.scene.stop('UIScene');
        this.scene.start('VictoryScene', { levelIndex: this.levelIndex });
      });
    }
  }

  private cleanupInactiveEntities(): void {
    this.projectileEntities = this.projectileEntities.filter((projectile) => projectile.active);
    this.grenadeEntities = this.grenadeEntities.filter((grenade) => grenade.active);
  }

  private emitHudState(): void {
    const weaponState = this.player.selectedWeapon;
    const reloadRatio =
      weaponState.reloadRemaining > 0
        ? 1 - weaponState.reloadRemaining / weaponState.definition.reloadTime
        : 0;
    const state: HudState = {
      health: this.player.health,
      maxHealth: this.player.maxHealth,
      armor: this.player.armor,
      maxArmor: this.player.maxArmor,
      dashRatio: this.player.dashRatio,
      grenades: this.player.grenades,
      maxGrenades: PLAYER_BALANCE.maxGrenades,
      weaponName: weaponState.definition.displayName,
      weaponColor: weaponState.definition.color,
      ammo: weaponState.ammo,
      reserveAmmo: weaponState.reserveAmmo,
      reloading: weaponState.reloadRemaining > 0,
      reloadRatio,
      alertState: this.alert.state,
      objectives: this.mission.objectives(),
      interactionPrompt: this.interactionPrompt,
      tacticalLog: this.tacticalLog,
      debugEnabled: this.debugEnabled,
      enemiesAlive: this.enemyEntities.filter((enemy) => !enemy.dead).length
    };
    eventBus.emit(GameEvents.HudState, state);
  }

  private emitMinimap(deltaSeconds: number): void {
    this.minimapTimer -= deltaSeconds;
    if (this.minimapTimer > 0) {
      return;
    }
    this.minimapTimer = 0.12;
    eventBus.emit(
      GameEvents.MinimapSnapshot,
      this.minimap.snapshot(
        this.player,
        this.enemyEntities,
        this.doorEntities,
        this.terminalEntities,
        this.mission.canExtract(),
        this.debugEnabled
      )
    );
  }

  private dropSupply(x: number, y: number): void {
    const roll = Math.random();
    const type: PickupType = roll < 0.45 ? 'ammo' : roll < 0.75 ? 'medkit' : 'grenade';
    const pickup = new Pickup(this, {
      x: x + Phaser.Math.Between(-18, 18),
      y: y + Phaser.Math.Between(-18, 18),
      type
    });
    this.pickupGroup.add(pickup);
  }
}
